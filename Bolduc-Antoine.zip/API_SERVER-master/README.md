# CRUD_Demo
This is a project that illustrate a minimal Node.js API server.
